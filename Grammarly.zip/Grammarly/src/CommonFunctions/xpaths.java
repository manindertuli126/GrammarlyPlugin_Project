package CommonFunctions;

public interface xpaths {
	
	String addToChromeBtn = "(//div[contains(text(),'Add to Chrome')])[1]";

}
